package MyMouseB;

use Mouse;

1;