package MyMetaclassRole;
use Mouse::Role;

1;
