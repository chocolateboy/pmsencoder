package MyMouseObject;

use strict;
use warnings;
use base 'Mouse::Object';

1;