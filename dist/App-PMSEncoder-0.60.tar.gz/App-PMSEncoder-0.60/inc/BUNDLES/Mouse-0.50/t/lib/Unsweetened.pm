package Unsweetened;
use strict;
use warnings;

sub unsweetened { 1 }

1;

