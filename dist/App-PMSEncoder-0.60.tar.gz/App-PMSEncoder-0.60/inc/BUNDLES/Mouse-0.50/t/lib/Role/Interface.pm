package Role::Interface;
use Mouse::Role;

requires "meth2";

1;
