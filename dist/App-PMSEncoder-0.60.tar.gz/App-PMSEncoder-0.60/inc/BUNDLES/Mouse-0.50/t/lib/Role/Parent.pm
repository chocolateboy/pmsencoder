package Role::Parent;
use Mouse::Role;

sub meth2  { }
sub meth1 { }

1;
