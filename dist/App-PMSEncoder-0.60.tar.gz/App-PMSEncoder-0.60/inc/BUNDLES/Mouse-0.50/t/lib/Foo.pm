
package Foo;
use Mouse;

has 'bar' => (is => 'rw');

1;